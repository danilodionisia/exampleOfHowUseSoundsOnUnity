﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Audio : MonoBehaviour {

    //Criando a variavel que armazena  o audio1
    public AudioSource audio1, audio2, audio3;
    //método que executa o arquivo de audio
    
    public void playAudio1()
    {        
        audio1.Play();
        
    }

    public void playAudio2()
    {
        audio2.Play();

    }

    public void playAudio3()
    {
        audio3.Play();

    }

    //método que pausa o arquivo de audio
    public void pauseAudio1()
    {
        audio1.Pause();
    }
    public void pauseAudio2()
    {
        audio2.Pause();
    }
    public void pauseAudio3()
    {
        audio3.Pause();
    }

    //método que para o arquivo de audio
    public void stopAudio1()
    {
        audio1.Stop();
    }
    public void stopAudio2()
    {
        audio2.Stop();
    }
    public void stopAudio3()
    {
        audio3.Stop();
    }


	void Start () {
		
	}
	
	
	void Update () {
		
	}
}
