﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Select : MonoBehaviour {
   
    public Text legenda;
    public int nAudio;
    public AudioSource Audio;
    public AudioClip clip1, clip2, clip3;
    public string[] texto;
	
    void Start () {
        nAudio = 1;
        legenda.text = "Audio 1";
        texto = new string[3];
        texto[0] = "Musica do Waldir";
        texto[1] = "Musica do Joao";
        texto[2] = "Musica do Lobinho";
	}

    public void nextAudio()
    {
        if (nAudio < 3)
        {
            Audio.Stop();
            nAudio++;
            legenda.text = texto[nAudio - 1];
            playAudio();
        }
    }

    public void lastAudio()
    {
        if (nAudio > 1)
        {
            Audio.Stop();
            nAudio--;
            legenda.text = texto[nAudio - 1];
            playAudio();
        }
    }

    public void playAudio()
    {
        switch (nAudio)
        {
            case 1:
                Audio.clip = clip1;
                break;
            case 2:
                Audio.clip = clip2;
                break;
            case 3:
                Audio.clip = clip3;
                break;
        }

        Audio.Play();
    }

	void Update () {
        
	}
}
